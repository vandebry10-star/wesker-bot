module.exports = {
  apps: [
    {
      name: 'wesker',
      script: 'index.js',
      watch: false,
      autorestart: true,
      max_restarts: 10,
      restart_delay: 3000,

      env: {
        NODE_ENV: 'production',
        GROQ_API_KEY: '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',
        MONGODB_URI: 'mongodb+srv://wesker:weskerkatanya@wesker.hra86hx.mongodb.net/?appName=wesker',
        MONGODB_DB: 'wesker',
        DEBUG: '0'
      }
    }
  ]
}
